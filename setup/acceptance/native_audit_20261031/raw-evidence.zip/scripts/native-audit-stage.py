import hashlib
import json
from pathlib import Path
import subprocess

repo = Path(r'C:\Users\fuker\Desktop\workspace\project-033-flexcell\code-clone')
out = repo/'artifacts/native-stale-20261031'
revision = subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip()
status = subprocess.check_output(['git','-C',str(repo),'status','--porcelain','--untracked-files=no'],text=True)
assert not status, status
archive = out/'patched-source.tar'
assert not archive.exists()
subprocess.run(['git','-C',str(repo),'archive','--format=tar','--output',str(archive),revision],check=True)
(out/'patched-source-revision.txt').write_text(revision+'\n')
receipt = dict(revision=revision,bytes=archive.stat().st_size,
               sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(out/'patched-source-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
