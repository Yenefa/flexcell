import collections
import json
from pathlib import Path

root = Path(r'C:\Users\fuker\Desktop\workspace\project-033-flexcell\code-clone\artifacts\native-stale-20261031')
raw = root / 'ci-base/native-five-window'
tables = {}
report = {'raw': str(raw), 'streams': {}}
for name in ('physics_steps', 'contact_steps'):
    path = raw / (name + '.jsonl')
    data = path.read_bytes()
    lines, partial = data.rsplit(b'\n', 1)
    rows = [json.loads(line) for line in lines.splitlines()]
    tables[name] = {r['sim_ns']: r for r in rows}
    gaps = sorted([(b['monotonic_ns']-a['monotonic_ns'], a['sim_ns'], b['sim_ns'], a['monotonic_ns'], b['monotonic_ns']) for a,b in zip(rows,rows[1:])], reverse=True)
    report['streams'][name] = dict(bytes=len(data), rows=len(rows), partial_bytes=len(partial), first={k:rows[0][k] for k in ('sim_ns','monotonic_ns')}, last={k:rows[-1][k] for k in ('sim_ns','monotonic_ns')}, duplicate_ticks=len(rows)-len(tables[name]), sim_gaps=collections.Counter(b['sim_ns']-a['sim_ns'] for a,b in zip(rows,rows[1:])), biggest_mono_gaps=gaps[:12])
events = [json.loads(line) for line in (raw/'native-events.jsonl').read_text().splitlines()]
report['events'] = [dict(cycle=e['cycle'], label=e['label'], request=e['request_mono_ns'], reply=e['reply_mono_ns'], duration_ns=e['reply_mono_ns']-e['request_mono_ns']) for e in events if e['label'] != 'heartbeat']
report['join'] = dict(common=len(tables['physics_steps'].keys() & tables['contact_steps'].keys()), max_stamp_skew_ns=max(abs(p['monotonic_ns']-tables['contact_steps'][ns]['monotonic_ns']) for ns,p in tables['physics_steps'].items() if ns in tables['contact_steps']))
release=events[-1]
for name, table in tables.items():
    tail = [r for r in table.values() if release['request_mono_ns']-1_000_000_000 < r['monotonic_ns'] < release['reply_mono_ns']+2_000_000_000]
    report['streams'][name]['release_window'] = [dict(sim=r['sim_ns'],mono=r['monotonic_ns'],attached=r.get('objects',{}).get('target_box_b',{}).get('joint_component')) for i,r in enumerate(tail) if i%40==0 or i==len(tail)-1]
(root/'ci-timeline.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
