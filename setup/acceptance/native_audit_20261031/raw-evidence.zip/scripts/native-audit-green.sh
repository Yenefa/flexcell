#!/usr/bin/env bash
set -eo pipefail
FC_STAGE=/home/ros/agentic_workcell_ws/build/preposition-world-stage
FC_REPO=/mnt/c/Users/fuker/Desktop/workspace/project-033-flexcell/code-clone
FC_OUT=/home/ros/agentic_workcell_ws/artifacts/native-stale-20261031
source /opt/ros/jazzy/setup.bash
source "$FC_STAGE/upstream/install/setup.bash"
source "$FC_STAGE/install/local_setup.bash"
export PYTHONDONTWRITEBYTECODE=1
cd "$FC_REPO"
python3 -m pytest -p no:cacheprovider src/flexcell/flexcell_skills/test/test_native_cycle_window.py -vv \
  > "$FC_OUT/lifetime-green.log" 2>&1
tail -n 8 "$FC_OUT/lifetime-green.log"
