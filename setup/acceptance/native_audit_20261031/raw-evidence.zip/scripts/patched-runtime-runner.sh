#!/usr/bin/env bash
set -eo pipefail
FC_QUALIFIED=/home/ros/agentic_workcell_ws/build/preposition-world-stage
FC_STAGE=/home/ros/agentic_workcell_ws/build/native-audit-stage
FC_OUT=/home/ros/agentic_workcell_ws/artifacts/native-stale-20261031
FC_CHAT=/mnt/c/Users/fuker/Documents/Codex/2026-10-30/https-github-com-yenefa-flexcell-https
FC_EXPORT=/mnt/c/Users/fuker/Desktop/workspace/project-033-flexcell/code-clone/artifacts/native-stale-20261031
mkdir "$FC_STAGE"
tar -xf "$FC_EXPORT/patched-source.tar" -C "$FC_STAGE"
cp "$FC_EXPORT/patched-source-revision.txt" "$FC_OUT/patched-source-revision.txt"
cp "$FC_EXPORT/patched-source-receipt.json" "$FC_OUT/patched-source-receipt.json"
cp "$0" "$FC_OUT/patched-runtime-runner.sh"
source /opt/ros/jazzy/setup.bash
source "$FC_QUALIFIED/upstream/install/setup.bash"
source "$FC_QUALIFIED/install/local_setup.bash"
export FLEXCELL_REPO="$FC_STAGE" FLEXCELL_WS="$FC_STAGE" FLEXCELL_INSTALL="$FC_QUALIFIED/install"
export FLEXCELL_SOURCE_REV="$(cat "$FC_OUT/patched-source-revision.txt")"
export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp ROS_DOMAIN_ID=45 ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
export LIBGL_ALWAYS_SOFTWARE=1 PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1
cd "$FC_STAGE"
grep -q '707 passed' "$FC_OUT/full-pytest.log"
python3 infra/runtime_identity.py > "$FC_OUT/patched-identity-before.json"
python3 "$FC_CHAT/work/native-reader-pause-repro.py" --source scripts/native_cycle_window.py \
  > "$FC_OUT/reader-pause-repro.json"
"$FC_QUALIFIED/build/flexcell_mtc/position_goal_test" \
  --gtest_output="xml:$FC_OUT/position-goal.xml" > "$FC_OUT/position-goal.log" 2>&1
"$FC_QUALIFIED/build/flexcell_mtc/attached_object_goal_test" \
  --gtest_output="xml:$FC_OUT/attached-object-goal.xml" > "$FC_OUT/attached-object-goal.log" 2>&1
# Instrumentation is identical to baseline except for the frozen source directory.
sed 's@build/preposition-world-stage@build/native-audit-stage@g' "$FC_OUT/diagnostic.py" \
  > "$FC_OUT/patched-diagnostic.py"
cp infra/native-five-cycle-window-after-audit-lifetime.json "$FC_OUT/patched-declaration.json"
sha256sum "$FC_OUT/patched-diagnostic.py" "$FC_OUT/patched-declaration.json" \
  > "$FC_OUT/patched-inputs.sha256"
started=$SECONDS
code=0
python3 "$FC_OUT/patched-diagnostic.py" --manifest "$FC_OUT/patched-declaration.json" \
  --out "$FC_OUT/patched-window" > "$FC_OUT/patched-window.log" 2>&1 || code=$?
printf 'exit_code\twall_seconds\n%d\t%d\n' "$code" "$((SECONDS-started))" > "$FC_OUT/patched-stage.tsv"
tail -n 10 "$FC_OUT/patched-window.log"
exit "$code"
