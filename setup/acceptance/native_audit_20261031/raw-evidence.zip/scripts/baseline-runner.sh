#!/usr/bin/env bash
set -eo pipefail
FC_STAGE=/home/ros/agentic_workcell_ws/build/preposition-world-stage
FC_OUT=/home/ros/agentic_workcell_ws/artifacts/native-stale-20261031
FC_CHAT=/mnt/c/Users/fuker/Documents/Codex/2026-10-30/https-github-com-yenefa-flexcell-https
mkdir "$FC_OUT"
source /opt/ros/jazzy/setup.bash
source "$FC_STAGE/upstream/install/setup.bash"
source "$FC_STAGE/install/local_setup.bash"
export FLEXCELL_REPO="$FC_STAGE" FLEXCELL_WS="$FC_STAGE" FLEXCELL_INSTALL="$FC_STAGE/install"
export FLEXCELL_SOURCE_REV=19caa0199660c6a0d9d95af14620695dde0eedcf
export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp ROS_DOMAIN_ID=45 ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
export LIBGL_ALWAYS_SOFTWARE=1 PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1
cd "$FC_STAGE"
python3 "$FC_CHAT/work/native-stale-preflight.py" > "$FC_OUT/environment-preflight.json"
cp "$FC_CHAT/work/native-stale-diagnostic.py" "$FC_OUT/diagnostic.py"
cp "$0" "$FC_OUT/baseline-runner.sh"
cp infra/native-five-cycle-window-after-epoch-selection.json "$FC_OUT/baseline-declaration.json"
sha256sum "$FC_OUT/diagnostic.py" "$FC_OUT/baseline-declaration.json" > "$FC_OUT/baseline-inputs.sha256"
python3 infra/runtime_identity.py > "$FC_OUT/baseline-identity.json"
started=$SECONDS
code=0
python3 "$FC_OUT/diagnostic.py" --manifest "$FC_OUT/baseline-declaration.json" \
  --out "$FC_OUT/baseline-window" > "$FC_OUT/baseline-window.log" 2>&1 || code=$?
printf 'exit_code\twall_seconds\n%d\t%d\n' "$code" "$((SECONDS-started))" > "$FC_OUT/baseline-stage.tsv"
tail -n 10 "$FC_OUT/baseline-window.log"
exit "$code"
