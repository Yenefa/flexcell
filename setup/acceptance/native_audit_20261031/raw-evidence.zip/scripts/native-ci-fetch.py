"""Retrieve one known failed CI artifact as binary and retain its exact ZIP."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import zipfile

root=Path(r'C:\Users\fuker\Desktop\workspace\project-033-flexcell\code-clone\artifacts\native-stale-20261031')
root.mkdir(parents=True,exist_ok=False)
archive=root/'native-five-41116653853.zip'
with archive.open('xb') as stream:
    subprocess.run(['gh','api','repos/Yenefa/flexcell/actions/artifacts/13004579974/zip'],stdout=stream,check=True)
target=root/'ci-base'
target.mkdir()
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for entry in bundle.infolist():
        name=PurePosixPath(entry.filename)
        assert not name.is_absolute() and '..' not in name.parts
        path=target.joinpath(*name.parts)
        assert path.resolve().is_relative_to(target.resolve())
        if entry.is_dir(): path.mkdir(parents=True,exist_ok=True)
        else:
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_bytes(bundle.read(entry))
    files=[entry.filename for entry in bundle.infolist() if not entry.is_dir()]
receipt=dict(workflow_run=41116653853,artifact_id=13004579974,bytes=archive.stat().st_size,
             sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),files=files)
(root/'download-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(receipt,indent=2))
