"""Archive completed native windows; compare every member with stable source bytes."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

root = Path('/home/ros/agentic_workcell_ws/artifacts/native-stale-20261031')
qualified = Path('/home/ros/agentic_workcell_ws/build/preposition-world-stage')
stage = Path('/home/ros/agentic_workcell_ws/build/native-audit-stage')
repo = Path('/mnt/c/Users/fuker/Desktop/workspace/project-033-flexcell/code-clone')
chat = Path('/mnt/c/Users/fuker/Documents/Codex/2026-10-30/https-github-com-yenefa-flexcell-https')
capsule = repo/'setup/acceptance/native_audit_20261031'
sha = lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
for name in ('baseline','patched'):
    assert json.loads((root/(name+'-window/result.json')).read_text())['status'] == 'PASS'
    assert (root/(name+'-stage.tsv')).read_text().splitlines()[1].split('\t')[0] == '0'
process = subprocess.run(['pgrep','-af','[g]z sim|[m]ove_group|[m]tc_planner|[c]arry_server|[r]ecord_sim_data'],capture_output=True,text=True)
assert process.returncode == 1, process.stdout
dirty = subprocess.check_output(['git','-C','/home/ros/agentic_workcell_ws','-c','core.filemode=false','diff','--binary'],stderr=subprocess.DEVNULL)
before = json.loads((root/'old-wsl-preflight.json').read_text())
assert hashlib.sha256(dirty).hexdigest() == before['dirty_patch_sha256']
entries = []
for name in ('baseline','patched'):
    window = root/(name+'-window')
    entries.extend((name+'/window/'+str(path.relative_to(window)),path)
                   for path in sorted(window.rglob('*')) if path.is_file())
for name in ('baseline-identity.json','patched-identity-before.json','baseline-stage.tsv','patched-stage.tsv',
             'baseline-inputs.sha256','patched-inputs.sha256','patched-source-revision.txt',
             'patched-source-receipt.json','old-wsl-preflight.json','reader-pause-repro.json',
             'lifetime-red.log','lifetime-red-corrected.log','lifetime-green.log','full-pytest.log',
             'full-pytest.xml','static-scan.log','position-goal.log','position-goal.xml',
             'attached-object-goal.log','attached-object-goal.xml'):
    entries.append(('preflight/'+name,root/name))
for name in ('locked-upstream.json','dependency-packages.tsv'):
    entries.append(('preflight/'+name,root.parent/'preposition-world-20261031'/name))
for member,path in [
    ('scripts/baseline-diagnostic.py',root/'diagnostic.py'),
    ('scripts/patched-diagnostic.py',root/'patched-diagnostic.py'),
    ('scripts/baseline-runner.sh',root/'baseline-runner.sh'),
    ('scripts/patched-runtime-runner.sh',root/'patched-runtime-runner.sh'),
    ('scripts/native-cycle-window-baseline.py',qualified/'scripts/native_cycle_window.py'),
    ('scripts/native-cycle-window-patched.py',stage/'scripts/native_cycle_window.py')]:
    entries.append((member,path))
for name in ('native-reader-pause-repro.py','native-ci-timeline.py','native-ci-fetch.py',
             'native-stale-preflight.py','native-audit-red.sh','native-audit-green.sh',
             'native-audit-tests.sh','native-audit-stage.py','native-audit-package.py'):
    entries.append(('scripts/'+name,chat/'work'/name))
historical = repo/'artifacts/native-stale-20261031'
entries.extend([('historical-ci/native-five-41116653853.zip',historical/'native-five-41116653853.zip'),
                ('historical-ci/download-receipt.json',historical/'download-receipt.json'),
                ('historical-ci/ci-timeline.json',historical/'ci-timeline.json')])
hashes = {name:sha(path) for name,path in entries}
assert len(hashes) == len(entries)
archive = capsule/'raw-evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as bundle:
    for name,path in entries:
        bundle.write(path,name)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None and set(bundle.namelist()) == set(hashes)
    for name,path in entries:
        assert hashlib.sha256(bundle.read(name)).hexdigest() == hashes[name] == sha(path),name
verification_sources = [
    'scripts/native_cycle_gate.py','scripts/integrated_contact_gate.py','scripts/contact_gate.py',
    'src/flexcell/flexcell_skills/flexcell_skills/joint_follow.py']
receipt = dict(baseline_source_revision='19caa0199660c6a0d9d95af14620695dde0eedcf',
    patched_source_revision=(root/'patched-source-revision.txt').read_text().strip(),
    historical_archive_sha256=sha(historical/'native-five-41116653853.zip'),
    archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,
    archive_members=len(entries),byte_verified_members=len(entries),files=hashes,
    verification_sources={name:sha(repo/name) for name in verification_sources},
    tests=dict(python_passed=707,cpp_passed=4,python_warnings=3,static_files=40,static_issues=0),
    cpp_test_binary_sha256={name:sha(qualified/'build/flexcell_mtc'/name)
                            for name in ('position_goal_test','attached_object_goal_test')},
    old_wsl_dirty_patch_sha256=before['dirty_patch_sha256'],old_wsl_dirty_patch_unchanged=True,
    remaining_runtime_processes=0,diagnostic_windows_per_version=1,no_replacements=True,
    historical_ci_pause_cause='UNKNOWN',default_admission='NO_GO')
(capsule/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
shutil.copyfile(chat/'work/native-reader-pause-repro.py',capsule/'native-reader-pause-repro.py')
for name in ('lifetime-red-corrected.log','lifetime-green.log','full-pytest.log','static-scan.log'):
    shutil.copyfile(root/name,capsule/name)
print(json.dumps({k:v for k,v in receipt.items() if k not in ('files','verification_sources')},indent=2))
