"""Read-only inventory of the existing dirty WSL checkout."""
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('/home/ros/agentic_workcell_ws')
out = repo/'artifacts/native-stale-20261031'
def git(*args):
    return subprocess.check_output(['git','-C',str(repo),'-c','core.filemode=false',*args],stderr=subprocess.DEVNULL)
patch = git('diff','--binary')
(out/'old-wsl-dirty.patch').write_bytes(patch)
status = git('status','--porcelain=v1','-z')
(out/'old-wsl-status.bin').write_bytes(status)
process = subprocess.run(['pgrep','-af','[g]z sim|[m]ove_group|[m]tc_planner|[c]arry_server|[r]ecord_sim_data'],text=True,capture_output=True)
assert process.returncode == 1, process.stdout
identity = dict(old_head=git('rev-parse','HEAD').decode().strip(),
    old_branch=git('branch','--show-current').decode().strip(),
    substantively_modified=git('diff','--name-only','--ignore-space-at-eol').decode().splitlines(),
    dirty_patch_sha256=hashlib.sha256(patch).hexdigest(),
    running_simulation_processes=0,
    preservation='Read-only; no normalization, restore, clean, reset, merge or build in dirty checkout.')
(out/'old-wsl-preflight.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps(identity,indent=2))
