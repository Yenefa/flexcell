"""Diagnostic wrapper only; preserve the original native fixture decisions."""
import collections
import gc
import json
import sys
import time
from pathlib import Path

stage = Path('/home/ros/agentic_workcell_ws/build/native-audit-stage')
sys.path.insert(0, str(stage/'scripts'))
import native_cycle_window as module

out = Path(sys.argv[sys.argv.index('--out')+1])
gc_events = collections.deque(maxlen=1000)
gc_started = {}
followers = []

def record_gc(phase, info):
    generation = info['generation']
    now = time.monotonic_ns()
    if phase == 'start':
        gc_started[generation] = now
    else:
        started = gc_started.pop(generation, now)
        if generation == 2 or now-started >= 10_000_000:
            gc_events.append(dict(generation=generation, started_ns=started, ended_ns=now,
                                  duration_ns=now-started, collected=info['collected']))

gc.callbacks.append(record_gc)
original = module.Follower

class DiagnosticFollower(original):
    def __init__(self, directory):
        super().__init__(directory)
        self.records = collections.deque(maxlen=128)
        self.slow = []
        self.waits = []
        self.collect_calls = 0
        self.max_collect_ns = 0
        followers.append(self)

    def collect(self):
        started = time.monotonic_ns()
        keys = super().collect()
        ended = time.monotonic_ns()
        self.collect_calls += 1
        elapsed = ended-started
        self.max_collect_ns = max(self.max_collect_ns, elapsed)
        rec = dict(start_ns=started,end_ns=ended,duration_ns=elapsed,
                   offsets=[s.tell() for s in self.streams],
                   table_last=[next(reversed(t)) if t else None for t in self.tables],
                   table_sizes=[len(t) for t in self.tables],
                   latest_common=keys[-1] if keys else None,
                   common_age_ns=ended-self.tables[0][keys[-1]]['monotonic_ns'] if keys else None)
        self.records.append(rec)
        if elapsed >= 20_000_000:
            self.slow.append(rec)
        return keys

    def wait(self, *args, **kwargs):
        boundary = dict(caller_line=sys._getframe(1).f_lineno, start_ns=time.monotonic_ns())
        self.waits.append(boundary)
        try:
            value = super().wait(*args, **kwargs)
            boundary['returned_sim_ns'] = value[0]['sim_ns']
            return value
        except Exception as exc:
            boundary['error'] = repr(exc)
            raise
        finally:
            boundary['end_ns'] = time.monotonic_ns()

module.Follower = DiagnosticFollower
module.__file__ = __file__
try:
    code = module.main()
finally:
    payload = dict(wrapper='diagnostic only; decisions and freshness limits unchanged',
        gc_events=list(gc_events), followers=[dict(collect_calls=f.collect_calls,
            max_collect_ns=f.max_collect_ns, slow=f.slow, tail=list(f.records), waits=f.waits)
            for f in followers])
    (out/('diagnostic-worker.json' if '--worker' in sys.argv else 'diagnostic-parent.json')).write_text(
        json.dumps(payload, indent=2)+'\n')
raise SystemExit(code)
