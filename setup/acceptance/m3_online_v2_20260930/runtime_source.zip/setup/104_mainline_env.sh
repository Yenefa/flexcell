#!/usr/bin/env bash
# Source this for every mainline stack, admin, client and runner process.
_flexcell_repo=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
export FLEXCELL_WS=${FLEXCELL_WS:-/home/ros/agentic_workcell_ws}
export FLEXCELL_INSTALL=${FLEXCELL_INSTALL:-/tmp/flexcell_mainline_20260930/install}
export ROS_DOMAIN_ID=${FLEXCELL_ROS_DOMAIN_ID:-45}
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp
if [ -n "${FLEXCELL_DDS_PROFILE:-}" ]; then
    export FASTRTPS_DEFAULT_PROFILES_FILE=$FLEXCELL_DDS_PROFILE
    export FASTDDS_DEFAULT_PROFILES_FILE=$FLEXCELL_DDS_PROFILE
else
    unset FASTRTPS_DEFAULT_PROFILES_FILE FASTDDS_DEFAULT_PROFILES_FILE
fi
export FLEXCELL_JEV_ENDPOINT=http://127.0.0.1:18081/v1/chat/completions
export FLEXCELL_JEV_MODEL=flexcell-fast
export FLEXCELL_LLM_ENDPOINT=http://127.0.0.1:18082/v1/chat/completions
export FLEXCELL_LLM_MODEL=flexcell-slow
# ROS setup scripts reference unset variables; preserve the caller's setting.
_flexcell_had_nounset=false
[[ $- == *u* ]] && _flexcell_had_nounset=true
set +u
source /opt/ros/jazzy/setup.bash
source "$FLEXCELL_WS/install/setup.bash"
source "$FLEXCELL_INSTALL/setup.bash"
$_flexcell_had_nounset && set -u
unset _flexcell_repo _flexcell_had_nounset
