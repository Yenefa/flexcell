#!/usr/bin/env bash
# Switch the owned fleet, or cold-start the owned stack, preserving old logs.
set -euo pipefail
action=${1:-switch}
policy=${2:-hybrid}
threshold=${3:-0.7}
repo=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
runtime=${FLEXCELL_WS:-/home/ros/agentic_workcell_ws}
base=${FLEXCELL_MAINLINE_ROOT:-/tmp/flexcell_mainline_20260930}
export FLEXCELL_INSTALL=${FLEXCELL_INSTALL:-$base/install}
export FLEXCELL_JEV_ENDPOINT=http://127.0.0.1:18081/v1/chat/completions
export FLEXCELL_JEV_MODEL=flexcell-fast
export FLEXCELL_LLM_ENDPOINT=http://127.0.0.1:18082/v1/chat/completions
export FLEXCELL_LLM_MODEL=flexcell-slow
case "$action" in cold|switch) ;; *) echo 'usage: 102_mainline_runtime.sh cold|switch fsm|jev|llm|hybrid [threshold]' >&2; exit 2;; esac
source "$repo/setup/104_mainline_env.sh"
pids=/tmp/flexcell_lifecycle/pids
logs=$base/runtime/$(date +%Y%m%d_%H%M%S)
mkdir -p "$logs" "$pids"
stop_owned() {
    local name=$1 pid pgid cmd
    [ -f "$pids/$name.pid" ] || return 0
    pid=$(cat "$pids/$name.pid")
    [[ "$pid" =~ ^[0-9]+$ ]] && [ "$pid" -gt 1 ] || { echo 'invalid owned PID'; exit 1; }
    kill -0 "$pid" 2>/dev/null || return 0
    pgid=$(ps -o pgid= -p "$pid" | tr -d ' ')
    cmd=$(ps -o args= -p "$pid")
    [ "$pgid" = "$pid" ] && [[ "$cmd" == *ros2*launch* ]] || { echo "ownership mismatch $name pid=$pid"; exit 1; }
    kill -TERM -- "-$pgid"
    for _ in $(seq 1 30); do kill -0 -- "-$pgid" 2>/dev/null || break; sleep 0.2; done
    if kill -0 -- "-$pgid" 2>/dev/null; then kill -KILL -- "-$pgid"; fi
    echo "STOPPED $name group=$pgid"
}
launch_owned() {
    local name=$1; shift
    setsid nohup "$@" >"$logs/$name.log" 2>&1 </dev/null &
    echo $! >"$pids/$name.pid"
    echo "STARTED $name pid=$! log=$logs/$name.log"
}
if [ -d /tmp/flexcell_lifecycle/logs ]; then cp -a /tmp/flexcell_lifecycle/logs "$logs/previous-stack"; fi
stop_owned fleet
if [ "$action" = cold ]; then
    stop_owned move_to_pose
    stop_owned moveit
    stop_owned gazebo
    timeout 15 ros2 daemon stop >/dev/null 2>&1 || true
    launch_owned gazebo ros2 launch open_manipulator_bringup open_manipulator_x_gazebo.launch.py world:=/mnt/f/flexcell-stage/worlds/flexcell_world
    ready=false
    for _ in $(seq 1 15); do
        if timeout 8 gz model --list 2>/dev/null | grep -q target_box_b; then ready=true; break; fi
        sleep 2
    done
    $ready || { echo 'Gazebo failed to start'; exit 1; }
    launch_owned moveit ros2 launch open_manipulator_moveit_config open_manipulator_x_moveit.launch.py use_sim:=true start_rviz:=false
    launch_owned move_to_pose ros2 launch flexcell_skills move_to_pose.launch.py
fi
fingerprint=$(python3 - "$logs/deployment.json" "$repo" "$policy" "$threshold" "$FLEXCELL_INSTALL" <<'PY'
import hashlib,json,os,pathlib,subprocess,sys
from flexcell_skills.contracts.benchmark_protocol import load_protocol
path,repo,policy,threshold,install=sys.argv[1:]
spec,digest=load_protocol()
profile_path=os.environ.get('FLEXCELL_DDS_PROFILE')
sources={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest()
         for p in pathlib.Path(repo).glob('src/flexcell/flexcell_skills/flexcell_skills/**/*.py')}
profile=dict(policy=policy,threshold=float(threshold),protocol_sha256=digest,
             source_sha256=sources,models=json.load(open(pathlib.Path(repo)/'setup/local_inference_assets.json')),
             policy_timeouts_s={'fast':2,'slow':5},server_context_tokens=8192,
             ros_domain_id=int(os.environ['ROS_DOMAIN_ID']),
             dds_profile_sha256=hashlib.sha256(pathlib.Path(profile_path).read_bytes()).hexdigest() if profile_path else 'builtin')
fingerprint=hashlib.sha256(json.dumps(profile,sort_keys=True).encode()).hexdigest()
json.dump(dict(profile, runtime_fingerprint=fingerprint,install=install,
               head=subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip()),open(path,'w'),indent=2)
print(fingerprint)
PY
)
export FLEXCELL_RUNTIME_FINGERPRINT=$fingerprint
launch_owned fleet bash "$repo/setup/98_run_policy.sh" "$policy" "$threshold"
timeout 65 python3 "$repo/setup/108_wait_policy.py" "$policy"
echo "DEPLOYED policy=$policy protocol=v2 logs=$logs"
