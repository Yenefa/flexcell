"""Offline ROS decoding of the original bag, never starting nodes or services."""
import hashlib
import json
from pathlib import Path
import sqlite3

from rclpy.serialization import deserialize_message
from tf2_msgs.msg import TFMessage

root = Path('/home/ros/agentic_workcell_ws/artifacts/legacy-release-20261101')
run, = (root / 'window/trial-01').glob('run-*')
out = root / 'tf-decoding'
out.mkdir(exist_ok=False)
files = sorted((run / 'data/raw').glob('*.db3'))
records = []
for db in files:
    connection = sqlite3.connect(db.as_uri() + '?mode=ro', uri=True)
    topics = connection.execute('SELECT id, name, type FROM topics').fetchall()
    topic_ids = [i for i, name, typ in topics if name == '/tf_static' and typ == 'tf2_msgs/msg/TFMessage']
    assert len(topic_ids) == 1, topics
    for msg_id, timestamp, data in connection.execute('SELECT id, timestamp, data FROM messages WHERE topic_id=? ORDER BY id', topic_ids):
        message = deserialize_message(data, TFMessage)
        transforms = []
        for t in message.transforms:
            transforms.append(dict(parent=t.header.frame_id, child=t.child_frame_id,
                stamp_ns=t.header.stamp.sec*10**9+t.header.stamp.nanosec,
                pose=[t.transform.translation.x, t.transform.translation.y, t.transform.translation.z,
                      t.transform.rotation.x, t.transform.rotation.y, t.transform.rotation.z, t.transform.rotation.w]))
        name = 'tf-static-%d.cdr' % msg_id
        (out / name).write_bytes(data)
        records.append(dict(bag=db.name, bag_sha256=hashlib.sha256(db.read_bytes()).hexdigest(),
                            message_id=msg_id, bag_timestamp_ns=timestamp, cdr=name,
                            cdr_sha256=hashlib.sha256(data).hexdigest(), transforms=transforms))
    connection.close()
assert records
(out / 'ros-decoded.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))

def rows(p):
    return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
for f in (run / 'skills').glob('*.jsonl'):
    if f.name.startswith('move_to_pose'):
        rs=rows(f)
        print('MOTIONS',json.dumps([{k:r.get(k) for k in ('request_id','request_timestamp','target','reached_pose','position_error_m','execution_end','wall_ts')} for r in rs],indent=2))
carry=rows(run / 'skills/carry.jsonl')
print('CARRY END',json.dumps([r for r in carry if r['event'] in ('follow_final','native_rpc','native_reply','release','stop','native_request')],indent=2))
