"""Read-only WSL inventory before one declared diagnostic, preserving old edits."""
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('/home/ros/agentic_workcell_ws')
out = repo / 'artifacts/legacy-release-20261101'
out.mkdir(exist_ok=False)

def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), '-c', 'core.filemode=false', *args], stderr=subprocess.DEVNULL)

patch = git('diff', '--binary')
(out / 'old-wsl-dirty.patch').write_bytes(patch)
(out / 'old-wsl-status.bin').write_bytes(git('status', '--porcelain=v1', '-z'))
processes = subprocess.run(['pgrep', '-af', '[g]z sim|[m]ove_group|[m]tc_planner|[c]arry_server|[r]ecord_sim_data|[s]im_window.py'], capture_output=True, text=True)
data = dict(old_head=git('rev-parse', 'HEAD').decode().strip(),
            old_branch=git('branch', '--show-current').decode().strip(),
            dirty_patch_sha256=hashlib.sha256(patch).hexdigest(),
            substantively_modified=git('diff', '--name-only', '--ignore-space-at-eol').decode().splitlines(),
            running_processes=processes.stdout.splitlines(),
            build_stages=sorted(p.name for p in (repo / 'build').glob('*stage*')),
            recent_artifacts=sorted(p.name for p in (repo / 'artifacts').iterdir())[-25:])
(out / 'environment-preflight.json').write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(data, indent=2))
assert processes.returncode == 1, 'another simulation is active; do not dispatch'
