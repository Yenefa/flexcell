"""Export only committed runtime inputs, with an explicit LF revision sidecar."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

repo = Path(r'C:\Users\fuker\Desktop\workspace\project-033-flexcell\code-clone')
out = Path(__file__).resolve().parent / 'legacy-release-20261101'
out.mkdir(exist_ok=False)
revision = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD']).decode().strip()
archive = out / 'runtime-source.tar'
subprocess.run(['git', '-C', str(repo), 'archive', '--format=tar', '-o', str(archive), revision,
                'src', 'scripts', 'infra', 'worlds', 'setup/flexcell_admin.py', 'plan_execute.py'], check=True)
with tarfile.open(archive) as tar:
    assert tar.pax_headers['comment'] == revision
data = dict(revision=revision, archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), archive_bytes=archive.stat().st_size)
(out / 'source-revision.txt').write_bytes((revision + '\n').encode('ascii'))
(out / 'frozen-source.json').write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
print(json.dumps(data))
