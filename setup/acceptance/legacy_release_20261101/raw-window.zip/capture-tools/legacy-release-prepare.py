"""Prepare new stage and a hash-bound diagnostic declaration, without dispatch."""
import hashlib
import json
from pathlib import Path
import sys
import tarfile

base = Path('/home/ros/agentic_workcell_ws')
out = base / 'artifacts/legacy-release-20261101'
chat = Path('/mnt/c/Users/fuker/Documents/Codex/2026-10-30/https-github-com-yenefa-flexcell-https')
frozen = chat / 'work/legacy-release-20261101'
stage = base / 'build/legacy-release-stage'
stage.mkdir(exist_ok=False)
meta = json.loads((frozen / 'frozen-source.json').read_text())
raw = (frozen / 'runtime-source.tar').read_bytes()
assert hashlib.sha256(raw).hexdigest() == meta['archive_sha256']
with tarfile.open(frozen / 'runtime-source.tar') as tar:
    assert tar.pax_headers['comment'] == meta['revision']
    tar.extractall(stage, filter='data')
qualified = base / 'build/preposition-world-stage'
(stage / 'install').symlink_to(qualified / 'install', target_is_directory=True)
(stage / 'upstream').symlink_to(qualified / 'upstream', target_is_directory=True)
for name in ('runtime-source.tar', 'source-revision.txt', 'frozen-source.json'):
    (out / name).write_bytes((frozen / name).read_bytes())
sys.path.insert(0, str(stage / 'scripts'))
from sim_profile import profile
import yaml
params, world = profile(out / 'profile-preview', 'detachable_joint', False, 'legacy',
                        physics_step_s=.002, contact_trace=True, qualification_no_recovery=True)
config = yaml.safe_load(params.read_text())
assert config['place_server']['ros__parameters']['release_clearance_m'] == .012
assert config['place_server']['ros__parameters']['place_tolerance_m'] == .06
for node in config.values():
    for key in list(node.get('ros__parameters', {})):
        if key in ('log_dir', 'episode_dir'):
            node['ros__parameters'][key] = '$RUN/' + key
manifest = stage / 'infra/legacy-release-diagnostic.json'
declaration = json.loads(manifest.read_text())
declaration.update(world_sha256=hashlib.sha256(world.read_bytes()).hexdigest(),
                   semantic_config_sha256=hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest())
(out / 'original-declaration.json').write_bytes(manifest.read_bytes())
(out / 'runtime-declaration.json').write_text(json.dumps(declaration, indent=2) + '\n')
print(json.dumps(declaration, indent=2))
