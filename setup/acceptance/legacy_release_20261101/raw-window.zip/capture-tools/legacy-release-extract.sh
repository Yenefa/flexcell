#!/usr/bin/env bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
python3 /mnt/c/Users/fuker/Documents/Codex/2026-10-30/https-github-com-yenefa-flexcell-https/work/legacy-release-extract.py
