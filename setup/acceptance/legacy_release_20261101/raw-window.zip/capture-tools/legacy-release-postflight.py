"""Seal only completed files after simulator and owned children have exited."""
import hashlib
import json
from pathlib import Path
import subprocess
import yaml

repo=Path('/home/ros/agentic_workcell_ws')
out=repo/'artifacts/legacy-release-20261101'
stage=repo/'build/legacy-release-stage'
old=repo/'build/preposition-world-stage'
processes=subprocess.run(['pgrep','-af','[g]z sim|[m]ove_group|[m]tc_planner|[c]arry_server|[r]ecord_sim_data|[s]im_window.py'], capture_output=True,text=True)
assert processes.returncode == 1, processes.stdout
before=json.loads((out/'environment-preflight.json').read_text())
patch=subprocess.check_output(['git','-C',str(repo),'-c','core.filemode=false','diff','--binary'],stderr=subprocess.DEVNULL)
assert hashlib.sha256(patch).hexdigest() == before['dirty_patch_sha256']
a=json.loads((out/'identity-before.json').read_text())
b=json.loads((out/'identity-after.json').read_text())
assert a == b and a['mismatches'] == []
compiled=[]
for p in (stage/'src/flexcell').rglob('*'):
    if p.is_file() and (p.suffix in ('.cpp','.hpp','.h','.xml') or p.name=='CMakeLists.txt'):
        relative=p.relative_to(stage)
        assert p.read_bytes()==(old/relative).read_bytes(),relative
        compiled.append(str(relative))
run,=(out/'window/trial-01').glob('run-*')
assert json.loads((out/'window/window.json').read_text())['status']=='STOPPED'
assert json.loads((run/'result.json').read_text())['recorder_exit']==0
config=yaml.safe_load((run/'params.yaml').read_text())
for node in config.values():
    for key in list(node.get('ros__parameters',{})):
        if key in ('log_dir','episode_dir'): node['ros__parameters'][key]='$RUN/'+key
(out/'semantic-config.json').write_text(json.dumps(config,indent=2)+'\n')
data=dict(running_simulation_processes=0, old_wsl_patch_unchanged=True,
          dirty_patch_sha256=before['dirty_patch_sha256'], runtime_identity_unchanged=True,
          native_compilation_input_files_equal_to_qualified_install=compiled,
          physical_tasks_dispatched=1, replacements=0, source_revision=a['source_revision'])
(out/'postflight.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))
