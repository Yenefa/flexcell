#!/usr/bin/env bash
set -eo pipefail
FC_BASE=/home/ros/agentic_workcell_ws/build/preposition-world-stage
FC_STAGE=/home/ros/agentic_workcell_ws/build/legacy-release-stage
FC_OUT=/home/ros/agentic_workcell_ws/artifacts/legacy-release-20261101
FC_CHAT=/mnt/c/Users/fuker/Documents/Codex/2026-10-30/https-github-com-yenefa-flexcell-https
source /opt/ros/jazzy/setup.bash
source "$FC_BASE/upstream/install/setup.bash"
source "$FC_BASE/install/local_setup.bash"
export FLEXCELL_REPO="$FC_STAGE" FLEXCELL_WS="$FC_STAGE" FLEXCELL_INSTALL="$FC_BASE/install"
export FLEXCELL_SOURCE_REV=66cff2e
export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp ROS_DOMAIN_ID=45 ROS_AUTOMATIC_DISCOVERY_RANGE=LOCALHOST
export GZ_PARTITION=flexcell-legacy-release-20261101 LIBGL_ALWAYS_SOFTWARE=1 PYTHONUNBUFFERED=1
export PYTHONDONTWRITEBYTECODE=1
export FLEXCELL_SOURCE_REV="$(cat "$FC_OUT/source-revision.txt")"
test "${#FLEXCELL_SOURCE_REV}" -eq 40
cd "$FC_STAGE"
cp "$0" "$FC_OUT/frozen-runtime-runner.sh"
python3 infra/runtime_identity.py > "$FC_OUT/identity-before.json"
started=$SECONDS
code=0
python3 scripts/sim_window.py --manifest "$FC_OUT/runtime-declaration.json" \
  --out "$FC_OUT/window" --backend detachable_joint --skill-backend legacy > "$FC_OUT/window.log" 2>&1 || code=$?
printf 'stage\texit_code\twall_seconds\nlegacy-release\t%d\t%d\n' "$code" "$((SECONDS-started))" > "$FC_OUT/runtime-stages.tsv"
python3 infra/runtime_identity.py > "$FC_OUT/identity-after.json"
tail -n 10 "$FC_OUT/window.log"
exit "$code"
