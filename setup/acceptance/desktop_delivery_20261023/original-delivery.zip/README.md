# flexcell-delivery (2026-10-23)

FlexCell M2 arm-test dataset: deterministic arm (`fsm`) and local model arm
(`jev`, Clef-Flash Q8_0 via llama.cpp `/v1/systemone`), 6 scenarios, 2 hosts
worth of bring-up evidence.

## Read it in this order

| need | file |
| --- | --- |
| everything in one JSON | `dataset/dataset.json` |
| one row per episode | `dataset/episodes.jsonl` (or `episodes.csv`) |
| headline numbers + Wilson CI | `dataset/pooled_summary.csv` |
| per-batch numbers | `dataset/scenario_summary.csv` |
| field dictionary | `dataset/README.md` |
| provenance + hashes | `dataset/run_manifest.json`, `MANIFEST.json` |
| verbatim runner output | `raw_batches/batch_*.jsonl` |
| unpushed fixes | `code/patches/`, `code/*.bundle`, `code/PUSH-INSTRUCTIONS.md` |

## Verify

```bash
sha256sum -c dataset/checksums.sha256
python3 - <<'PY'
import json, pathlib
schema = json.load(open('dataset/schema.json'))
props = set(schema['properties'])
for i, line in enumerate(open('dataset/episodes.jsonl'), 1):
    rec = json.loads(line)
    assert set(rec) == props, (i, set(rec) ^ props)
print('episodes:', i, 'schema: ok')
PY
```

`MANIFEST.json.files` carries the sha256 of every file in this package.

## Rules baked into the data (do not "fix" them)

- Records from different `runtime_fingerprint` are **never pooled**; the two
  arms (`fsm`, `jev`) and the pre-fix runtime all have distinct fingerprints.
- `as_expected = false` rows are kept on purpose: they are the S7 pre-fix
  failure and the seed-20260931 reproduction that motivated the fixes in
  `code/patches/`.
- Task-level `error_code` (50/51) is generic by design; skill-level codes live
  in `detail_codes`. The `jev` arm currently drops them (known gap, see
  `dataset/README.md`).
