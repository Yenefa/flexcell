# 如何把这三处修复推上去（本机无 GitHub 凭据）

本机是公共电脑，按约定不登录任何账号，所以 `git push` 被挡在
`could not read Username for 'https://github.com'`。
本地已有 4 个提交（都在 `fix/pick-lift-release` 分支上，基于 `main a9b6a62`）：

```
ed0cf0a docs(acceptance): 2026-10-21 DESKTOP-8JBM0GF bring-up evidence
011bb09 fix(s7): keep perturbation placements inside the LIFT-reachable envelope
110ae98 fix(pick): release the carry servo when the LIFT motion fails
c15187d fix(decision_policy): keep the typed skill code in the PLACE abort detail
```

## 方式 A：补丁系列（推荐，最稳）

把 `patches/` 里 4 个 `.patch` 拷到你有权限的机器（或直接在能推的克隆里 `git am`）：

```bash
git checkout main && git pull            # 确认是 a9b6a62 或其后
git switch -c fix/pick-lift-release
git am /path/to/patches/000*.patch       # 顺序执行 0001..0004
git push -u origin fix/pick-lift-release
```

## 方式 B：git bundle（一条命令，保住提交流水线）

```bash
git fetch origin                          # 需要先有 a9b6a62
git bundle verify flexcell-fixes-20261021.bundle
git bundle unbundle flexcell-fixes-20261021.bundle
# bundle 的 ref 名是 fix/pick-lift-release，unbundle 后按提示建分支：
git switch -c fix/pick-lift-release <bundle 输出的 sha>
git push -u origin fix/pick-lift-release
```

## 之后

- 开 PR：`fix/pick-lift-release` → `main`。三个代码提交各自独立，可按需拆成 3 个 PR
  （`c15187d` 是 typing/门禁口径、`110ae98` 是 pick 失败释放、`011bb09` 是 S7 包络）。
- **不要直接推 main**（仓库约定：推 main 需授权）。
- 推完回来告诉我，我把本地分支的 upstream 标好，后续继续跑就不用再走搬运。
