# flexcell-arm-test dataset (schema_version 1)

Machine-readable export of the FlexCell scenario-runner batches run on
DESKTOP-8JBM0GF (2026-10-21 and 2026-10-23, policy=fsm).

| file | shape | use |
| --- | --- | --- |
| `episodes.jsonl` | 1 JSON object per line | streaming / grep / jq |
| `episodes.csv` | header + rows | pandas / Excel / R |
| `scenario_summary.csv` | per (batch, scenario) | headline table, Wilson CI |
| `run_manifest.json` | object | provenance: env, git head, input+output sha256 |
| `dataset.json` | object | everything in one file (manifest + episodes) |
| `schema.json` | JSON Schema 2020-12 | validate `episodes.jsonl` |

## Record fields (`episodes.jsonl`)

| field | type | meaning |
| --- | --- | --- |
| `schema_version` | int | 1 |
| `batch_id` / `batch_date` | str | source batch (`batch_<YYYYMMDD>_<HHMMSS>`) and its date |
| `scenario` | str | `S1` canonical, `S2` inject-A, `S3` inject-B, `S4` unreachable place, `S5` retry exhausted, `S7` perturbed placement |
| `run` / `seed` | int | index within the cell; runner seed (`base + n`) |
| `stage` | str | `smoke` (<=5 per cell) or `baseline` (requires passing smoke) |
| `policy` | str | `fsm` here (no model involved) |
| `protocol_id` / `protocol_version` / `protocol_sha256` | str/int | benchmark protocol identity |
| `runtime_fingerprint` | str | hash of sources+params+plugin+world; batches only pool when equal |
| `outcome` / `expected` / `as_expected` | str/bool | measured vs expected (`S4`/`S5` expect `FAILED`) |
| `error_code` | str | task-level code (`ERR_NONE`, `ERR_SKILL_FAILED` 50, `ERR_RECOVERY_EXHAUSTED` 51) |
| `detail` | str | one-line task detail |
| `detail_codes` | str | typed skill codes found inside `detail`, `;`-separated (e.g. `ERR_MOTION_FAILED`) |
| `fsm_trace` | str | `|`-joined decision/attempt trace |
| `run_id` / `evidence_id` | str | episode and evidence identifiers |
| `wall_seconds` | float | episode duration |
| `object_a_at_zone` / `object_b_at_zone` | bool | task-level placement verdict |
| `zone_a_error_m` / `zone_b_error_m` | float | measured placement error (null when the leg never ran) |
| `final_position_error_m` | float | single-object tasks only |
| `replay_ok` / `replay_status` / `replay_steps` | bool/str/int | offline policy-input replay of the episode |
| `model_decisions` | int | 0 for `fsm` |
| `inject_arm` / `inject_clear` | str | failure-injection state at episode start/end |
| `reset_rc` / `rc` | int | process exit codes (judge by JSON, not these) |
| `harness_error` | str/null | runner-level failure (`perturbation failed`, fingerprint mismatch, ...) |
| `scenario_exercised` | bool | the scenario actually reached its intended code path |
| `p_a_*` / `p_b_*` | float | S7 perturbation placement of box A/B (`null` outside S7) |

## Load snippets

```bash
# counts per scenario / outcome
jq -r '[.scenario, .outcome] | @tsv' episodes.jsonl | sort | uniq -c
# typed failures only
jq -c 'select(.detail_codes != null)' episodes.jsonl
# success rate per scenario (baseline only)
jq -r 'select(.stage=="baseline") | [.scenario, (.outcome=="SUCCEEDED")] | @tsv' episodes.jsonl \
  | awk '{n[$1]++; s[$1]+=$2} END {for (k in n) printf "%s %d/%d\n", k, s[k], n[k]}'
```

```python
import json, pandas as pd
df = pd.read_json('episodes.jsonl', lines=True)
print(df.groupby(['scenario', 'stage']).outcome.value_counts())
```

## Provenance notes

- `run_manifest.json.batches[].sha256` hashes the raw `batch_*.jsonl` inputs;
  `run_manifest.json.outputs` hashes these files.
- Batches with different `runtime_fingerprint` are **not** pooled (project red line).
- The two `as_expected=false` rows are preserved on purpose: the pre-fix S7 run
  (`ERR_SAFETY_REJECTED`) and the seed-20260931 reproduction run. They document
  the defects fixed in `110ae98` / `011bb09`; do not drop them.
