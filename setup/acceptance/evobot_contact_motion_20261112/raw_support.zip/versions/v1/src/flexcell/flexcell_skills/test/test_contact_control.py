"""Contact geometry, native evidence and post-return refusal invariants."""
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import Mock
import json
import math
import time

import numpy as np
import pytest

from flexcell_skills.contact_geometry import ContactGeometry,clip,box_intersects,apply
from flexcell_skills.contact_receipt import ContactReceipt,ReturnedState,ready_for_next
from flexcell_skills.contact_trace import JsonTail,NativeContact,patch_distance


def arm():
    model=ContactGeometry.__new__(ContactGeometry)
    model.limits=[(-math.pi,math.pi),(-1.5,1.5),(-1.5,1.4),(-1.7,1.97)]
    return model


def test_fk_matches_archived_independent_tf_composition():
    references=json.loads((Path(__file__).parent/'data/contact_reference_states.json').read_text())
    model=arm()
    for row in references:
        pose=model.frames(row['joints'])['end_effector_link']
        assert np.linalg.norm(pose[:3,3]-row['ee_position'])<.001


def test_fixed_pitch_ik_preserves_the_measured_configuration_branch():
    model=arm()
    for q in [[0.,0.,0.,0.],[-.1,.8,-.95,1.63],[.2,.4,-.3,1.0]]:
        point=model.frames(q)['end_effector_link'][:3,3]
        solved=model.inverse(point,sum(q[1:]),q)
        assert np.max(np.abs(solved-q))<1e-7


def test_lateral_finger_tcp_is_not_the_virtual_end_effector_origin():
    model=arm();q=[-.1,.8,-.95,1.63];tcp=[-.013,.0216,-.0157]
    pose=model.frames(q)['end_effector_link'];point=apply(pose,tcp)
    recovered=model.tcp_inverse(point,sum(q[1:]),tcp,q)
    assert np.max(np.abs(recovered-q))<1e-7
    assert np.linalg.norm(point-pose[:3,3])>.02


def test_unreachable_fixed_orientation_is_refused_instead_of_relaxed():
    with pytest.raises(ValueError,match='unreachable'):
        arm().inverse([.6,0.,.1],math.pi/2,[0.]*4)


def test_real_triangle_distance_refuses_an_invented_bounding_box_corner():
    triangle=[[[0.,0.,0.],[1.,0.,0.],[0.,1.,0.]]]
    assert patch_distance([.2,.2,.001],triangle)==pytest.approx(.001)
    assert patch_distance([1.,1.,0.],triangle)==pytest.approx(math.sqrt(.5))
    assert patch_distance([2.,0.,0.],triangle)==pytest.approx(1.)


def test_clipped_surface_points_stay_on_the_actual_triangle():
    tri=np.array([[0.,-2.,0.],[0.,2.,0.],[0.,0.,2.]])
    poly=clip(clip(list(tri),1,-.5,True),1,.5,False)
    for point in poly:assert patch_distance(point,[tri])<1e-12


def test_collision_detection_catches_edges_when_all_vertices_are_outside():
    tri=np.array([[[-2.,0.,0.],[2.,0.,0.],[0.,2.,0.]]])
    assert box_intersects(tri,[0.,0.,0.],.1)
    tri=np.array([[[.2,0.,0.],[0.,.2,0.],[.2,.2,0.]]])
    assert not box_intersects(tri,[0.,0.,0.],.05)


def returned():
    return ReturnedState('SIMULATION_GROUND_TRUTH','world',.01,True,True,True,True,.08,0.,(.19,0.,.0175),5,
                         10_000_000_000,time.monotonic_ns())


def receipt(post=None,**fields):
    values=dict(request_id='one',primitive_outcome='SUCCEEDED',primitive_error_code=0,stroke_signed_m=.03,
        requested_m=.03,physical_contact_observed=True,motion_terminal_known=True,return_completed=True,
        canceled=False,post_return=post or returned(),attempt_start=(.22,0.,.0175))
    values.update(fields);return ContactReceipt(**values)


def test_returned_receipt_keeps_motion_readiness_separate_from_task_acceptance():
    r=receipt();value=r.to_dict()
    assert r.arm_ready and value['returned_request_geometry_satisfied']
    assert value['independent_acceptance_claim'] is False


@pytest.mark.parametrize('patch',[dict(source_age_s=.6),dict(arm_quiet=False),dict(object_stable=False),
    dict(carry_disengaged=False),dict(gripper_state_known=False),dict(tool_clearance_m=.04),
    dict(protected_excursion_m=.006),dict(source='UNKNOWN')])
def test_missing_or_unsafe_post_state_cannot_become_ready(patch):
    r=receipt(replace(returned(),**patch))
    assert not r.arm_ready
    assert r.to_dict()['returned_request_geometry_satisfied'] is None


def test_pre_return_stroke_success_does_not_hide_lost_progress():
    r=receipt(replace(returned(),position=(.23,0.,.0175)))
    value=r.to_dict()
    assert r.arm_ready  # physically safe to reconsider the task, not a successful push
    assert value['returned_signed_m']==pytest.approx(-.01)
    assert value['return_loss_m']==pytest.approx(.04)
    assert value['progress_preserved'] is False and value['returned_request_geometry_satisfied'] is False


def test_returned_distance_cannot_hide_an_off_axis_motion():
    r=receipt(replace(returned(),position=(.19,.019,.0175)))
    assert r.arm_ready
    assert r.to_dict()['returned_request_geometry_satisfied'] is False


@pytest.mark.parametrize('patch',[dict(motion_terminal_known=False),dict(return_completed=False),dict(canceled=True)])
def test_unknown_motion_or_incomplete_return_never_dispatches_as_ready(patch):
    assert not receipt(**patch).arm_ready


def test_success_cannot_use_a_missing_physical_contact_observation():
    with pytest.raises(ValueError):receipt(physical_contact_observed=None)


def test_latched_ready_requires_current_clock_and_world_revision():
    value=receipt().to_dict();post=value['post_return']
    assert ready_for_next(value,post['source_stamp_ns'],5,post['observed_monotonic_ns'])
    assert not ready_for_next(value,post['source_stamp_ns'],6,post['observed_monotonic_ns'])
    assert not ready_for_next(value,post['source_stamp_ns']+600_000_000,5,post['observed_monotonic_ns'])
    assert not ready_for_next(value,post['source_stamp_ns'],5,post['observed_monotonic_ns']+300_000_000)


def test_json_tail_does_not_treat_a_partial_native_record_as_no_contact(tmp_path):
    path=tmp_path/'stream';path.write_text('{"x"');tail=JsonTail(path)
    assert tail.read()==[]
    with path.open('a') as f:f.write(':1}\n')
    assert tail.read()==[{'x':1}]


def test_absent_native_files_remain_unknown(tmp_path):
    native=NativeContact(tmp_path,'a',{})
    native.poll();assert native.observed() is None


def test_native_contact_uses_physical_parent_plus_fixed_tcp_transform(tmp_path):
    native=NativeContact(tmp_path,'a',{})
    now=time.monotonic_ns();physics=dict(sim_ns=1,monotonic_ns=now,parent_pose=[0.,0.,0.,0.,0.,0.,1.])
    reg=dict(finger='gripper_left_link',patch_in_ee=[[[0.,0.,0.],[.001,0.,0.],[0.,.001,0.]]])
    native.begin(reg)
    row=dict(sim_ns=1,monotonic_ns=time.monotonic_ns(),targets={'a':dict(component_present=True,
        pose=[.1085,0.,0.,0.,0.,0.,1.],contacts={'contact':[dict(collision1={'name':'a::link::col'},
        collision2={'name':'open_manipulator_x::gripper_left_link::gripper_left_link_collision'},
        position=[dict(x=.126,y=0.,z=0.)],normal=[dict(x=1.,y=0.,z=0.)])]} )})
    (tmp_path/'physics.jsonl').write_text(json.dumps(physics)+'\n')
    (tmp_path/'contacts.jsonl').write_text(json.dumps(row)+'\n')
    native.poll();assert native.observed() is True
    assert native.max_patch_error<1e-12


def test_unknown_goal_response_latches_before_any_cleanup_goal(monkeypatch):
    import flexcell_skills.contact_motion as module
    monkeypatch.setattr(module,'ActionClient',Mock())
    node=Mock();motion=module.ConstrainedMotion(node,Mock(),Mock(),lambda _:None,Mock(),lambda:False)
    future=Mock();future.done.return_value=False
    with pytest.raises(module.MotionUnknown):motion.wait(future,.001,physical=True)
    assert motion.blocked and not motion.terminal_known
    with pytest.raises(module.MotionUnknown):motion.execute({},'RETURN')
    motion.action.send_goal_async.assert_not_called()


def test_self_collision_refusal_cannot_register_or_dispatch(monkeypatch):
    import flexcell_skills.contact_motion as module
    monkeypatch.setattr(module,'ActionClient',Mock())
    node=Mock();node.create_client.side_effect=[Mock(),Mock()];q=np.zeros(4)
    motion=module.ConstrainedMotion(node,arm(),lambda:(q,(0.,0.)),lambda _:None,Mock(),lambda:False)
    motion.action.wait_for_server.return_value=True
    motion.registration.wait_for_service.return_value=True;motion.validity.wait_for_service.return_value=True
    future=Mock();future.done.return_value=True;future.result.return_value=NS(valid=False)
    motion.validity.call_async.return_value=future
    with pytest.raises(module.MotionFailed,match='self-collision'):
        motion.execute(dict(positions=np.array([q,q])),'STROKE')
    motion.registration.call_async.assert_not_called();motion.action.send_goal_async.assert_not_called()
