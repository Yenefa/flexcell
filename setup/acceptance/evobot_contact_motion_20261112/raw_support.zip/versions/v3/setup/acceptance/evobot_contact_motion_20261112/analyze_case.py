"""Read-only replay of native trajectories and emitted returned-state receipts.

This does not replace the frozen task evaluator. Native world poses, rather than
ROS /tf link transforms, establish physical TCP motion.
"""
import argparse
import json
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / 'src/flexcell/flexcell_skills'))
from flexcell_skills.contact_receipt import ready_for_next
from flexcell_skills.contact_trace import rotation


def rows(path):
    with path.open() as stream:
        for line in stream:
            yield json.loads(line)


def analyze(directory):
    trial=directory/'trial'
    events=list(rows(trial/'events.jsonl'))
    phases=[];active=None;attempt=-1
    for event in events:
        if event['kind']=='DECISION' and event['decision']=='push':attempt+=1
        if event['kind']=='CONSTRAINED_DISPATCH':
            active=dict(event,attempt=attempt,points_native=[])
            phases.append(active)
        if event['kind']=='CONSTRAINED_TERMINAL' and active is not None:
            active['terminal']=event;active=None
    registers={int(p.stem.rsplit('_',1)[1]):json.loads(p.read_text())
               for p in trial.glob('contact_frame_*.json')}
    target_positions=[];native_count=0
    for row in rows(directory/'physics.jsonl'):
        native_count+=1;target_positions.append(row['objects']['target_box_a']['pose'][:3])
        for phase in phases:
            terminal=phase.get('terminal',{})
            if phase['monotonic_ns']<=row['monotonic_ns']<=terminal.get('monotonic_ns',0):
                parent=row['parent_pose'];R=rotation(parent[3:])
                tcp=np.asarray(registers[phase['attempt']]['tcp'])+[.126,0.,0.]
                actual=np.asarray(parent[:3])+R@tcp
                pitch=float(np.arctan2(-R[2,0],np.hypot(R[0,0],R[1,0])))
                phase['points_native'].append([*actual,pitch])
    result=[]
    for phase in phases:
        points=np.asarray(phase.pop('points_native'))
        entry={k:phase[k] for k in ('phase','attempt','request_id','duration_s','tcp_start','tcp_end','pitch_start','pitch_end')}
        entry['terminal']=phase.get('terminal');entry['native_samples']=len(points)
        if len(points):
            entry['tcp_actual_start_m']=points[0,:3].tolist()
            entry['tcp_actual_end_m']=points[-1,:3].tolist()
            entry['endpoint_error_m']=float(np.linalg.norm(points[-1,:3]-phase['tcp_end']))
            if phase['phase']=='STROKE':
                origin=np.asarray(phase['tcp_start'])
                delta=points[:,:3]-origin
                entry.update(forward_travel_m=float(-delta[-1,0]),
                    maximum_lateral_vertical_error_m=float(np.linalg.norm(delta[:,1:],axis=1).max()),
                    maximum_pitch_error_rad=float(np.abs(points[:,3]-phase['pitch_end']).max()))
        result.append(entry)
    receipts=[]
    for event in events:
        if event['kind']!='POST_RETURN_RECEIPT':continue
        value=event['receipt'];post=value.get('post_return')
        entry=dict(receipt=value)
        if post:
            entry['ready_at_emission_replayed']=ready_for_next(value,event['sim_ns'],post['revision'],event['monotonic_ns'])
            entry['expired_300ms_later']=not ready_for_next(value,event['sim_ns'],post['revision'],event['monotonic_ns']+300_000_000)
        receipts.append(entry)
    positions=np.asarray(target_positions)
    return dict(native_physics_samples=native_count,
        net_signed_m=float(positions[0,0]-positions[-1,0]) if len(positions) else None,
        maximum_object_center_z_m=float(positions[:,2].max()) if len(positions) else None,
        constrained_phases=result,receipts=receipts,
        summary=json.loads((trial/'contact_summary.json').read_text()),
        independent_verdict=json.loads((directory/'verdict.json').read_text()))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path);parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    data=analyze(args.directory)
    with args.out.open('x') as stream:json.dump(data,stream,indent=2,allow_nan=False)
    print(json.dumps({k:v for k,v in data.items() if k not in ('constrained_phases','receipts')},indent=2))
