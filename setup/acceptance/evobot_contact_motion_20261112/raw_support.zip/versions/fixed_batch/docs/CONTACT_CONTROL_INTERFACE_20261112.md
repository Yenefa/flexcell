# Finger contact, constrained motion and returned-state interface

Isolated development branch `develop/t08-contact-motion-20261112`, based on
6186271b. This interface is not the formal execution baseline or an autonomous
L4 claim. TaskSpecs, nine frozen files, `contracts/push.py`, gripper acceptance
and the existing MoveToPose server remain unchanged.

## Three concrete interfaces

`ContactGeometry.register_finger()` reads the exact simulation collision meshes
and URDF, composes the four-joint FK with both measured gripper positions, and
registers a point on an actual finger triangle. Its record includes TCP in
`end_effector_link`, triangle/plane patch, world support point and normal,
approach configuration, gripper state and source hashes. The virtual EE origin
and the STL bounding-box corner are not contact points. The current adapter
requires upright 35 mm boxes, a world -x stroke and the pinned robot geometry.

`ContactGeometry.cartesian()` generates a dense TCP path with explicit pitch,
analytical IK and a consistent elbow branch. Knot spacing, joint limits, mesh
floor clearance, protected-object exclusion and controller interpolation are
checked before dispatch. Approach and return also exclude the target. Joint
velocity/acceleration bounds correspond to `demo_veryslow`. Sampled MoveIt
self-collision validation precedes registration; it is not a proof of continuous
self-collision freedom. Native trajectories provide the independent check of
actual TCP/pitch tracking.

`ConstrainedMotion.execute()` hands that trajectory to the existing MoveToPose
owner through its one-use trajectory registration service. It does not create a
second controller owner. The existing internal token prefix causes the server
log to call this backend `attached_point`; here the trajectory comes from the
finger-TCP planner, without an attached object or an MTC planning call.
Unknown dispatch/terminal status latches the adapter and forbids further goals,
including cleanup. Cancellation requires the server's strict stop confirmation.

`ContactReceipt` separates the pre-return primitive outcome from physical
contact evidence, return completion, known motion terminal and actual returned
object pose. The JSON schema is `contact-push-receipt/1`; it is also published as
`std_msgs/String` on `/flexcell/contact_push_receipt` with transient-local depth1.
The standalone CLI is the producer. This is not yet a custom ROS action or a
DecisionPolicy/Runtime integration.

## Consuming a returned state

`arm_ready` means the arm can be reconsidered for another action. It requires a
completed return, known terminal, no caller cancellation, fresh quiet joints,
stable measured object snapshots, known gripper, disengaged carry, sufficient
tool clearance and an undisturbed protected object. It does not mean the push or
the complete task succeeded. A successful stroke with a failed return retains
its stroke verdict and emits `arm_ready=false`.

Consumers must call
`ready_for_next(receipt, now_sim_ns, current_world_revision, now_monotonic_ns)`.
It checks source age, revision and the same-host observation time again. The
latched boolean expires; it must not authorize a later motion by itself.
Monotonic timestamps are only comparable on the same host/boot. ROS source stamps
use simulation time. Another process must freshly observe and replan; this
receipt does not reserve the robot or bypass the executor's admission control.

`returned_signed_m` is the signed net -x displacement. `return_loss_m` compares
it with the pre-return measurement. `returned_request_geometry_satisfied`
reuses frozen push distance/direction/lateral/vertical limits. Independent
full-task acceptance always comes from the frozen evaluator after execution.

## Running and reviewing

`run_contact_push.py TASK OUT --model MODEL --attempts 2` is an exposed-task
engineering experiment. It reads `expected_goal`; it is not an autonomous Agent
experiment with public inputs only. It uses measured object progress after each
at-most4mm stroke segment and the unchanged `push.judge` conditions.

The acceptance directory contains the preregistration, one-case harness,
real-ROS synthetic protocol checks and a read-only native replay analyzer.
Model files/license, executed source versions, logs, failed experiments and
source hashes belong in the evidence archive. See its README for measured
outcomes and exact replay commands. Do not infer robot capability from unit or
synthetic protocol tests.
