Public instruction Runtime acceptance
=====================================

The task is to close the gap between the engineering contact driver and actual
task execution. Runtime receives only public task fields, observes the scene,
resolves the requested object and region, submits RunComposite, consumes typed
ContactPush results and a fresh final observation, and makes a success claim.
This is a bounded deterministic rule policy, not an LLM or L4 Develop claim.

Before any physical execution the sequence is:

1. R0: legacy Runtime backend on the unchanged exposed T08 seed2000 task.
2. R1: finger_tcp Runtime backend on that same exposed task.
3. After implementation is frozen, R2: the same Runtime on the separately
   declared blue-object probe (probe_blue.json). The blue object starts at
   (0.215,0.010,0.0175), the protected red object at (0.200,-0.180,0.0175),
   and the public region is centred at (0.115,0.010,0.0175), radius 0.060.

All slots are retained, including startup and Runtime failures. Corrections
require a new source hash and labelled slot. R2 is a new validation instance
declared during development, not a sealed or formally held-out evaluation.
No old TaskSpec, frozen evaluator, generator, threshold, push arithmetic or
gripper acceptance rule changes. New probe uses the same acceptance limits.

The task-scoped graph retains Observe, Carry, TaskFSM, actuator/physics stack,
and the selected push backend. The TaskFSM coordinator uses wall clock because
its budget and lifecycle logic use monotonic time; it never reads simulation
clock. The contact worker uses simulation clock. This configuration does not
resolve full default-graph scheduling (#237). Native traces, measured joints,
WorldState and independent unchanged full-nine-clause acceptance are required.

Record task completion separately from component success, returned-state
readiness and agent claim. Legacy Runtime failure with physical acceptance
does not establish task-rate superiority. Each task keeps its 40 actuator-goal
and 600-second public execution budget. No favourable replacement runs, model
spending, hardware commands, baseline promotion, main merge or PR.

R0 configuration correction (before any candidate run): the legacy backend
requires an explicit contact height, but the initial harness omitted it.
R0 therefore refused with no actuator goal and is an invalid physical control,
retained in full. R0b repeats that control with the previously declared 20 mm
contact-height parameter. No planner, candidate or acceptance changes. The
additional control is a labelled harness correction, not a replacement result.
